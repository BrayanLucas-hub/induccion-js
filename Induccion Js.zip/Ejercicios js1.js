let Num;

Num=parseInt(prompt("Ingrese su numero"))

if(Num >= 100 && Num <=999){
    alert("Su numero tiene 3 digitos")
}else{
    alert("Su numero no tiene 3 digitos")
}

