let Numero;

Numero=parseInt(prompt("Ingrese su numero"))
// Math.floor sirve para redondear un decimal y solo dejar su parte entera
let decenas = Math.floor(Numero/10);
let unidades = Numero % 10;
let suma = decenas + unidades;

   alert("La suma de sus digitos es " + suma);
