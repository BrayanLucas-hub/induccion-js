let Numero;
let Division = Numero / 2;
let Residuo = Numero % 2;

Numero=parseInt(prompt("Ingrese su numero"))

if(Division = Numero / 2 === 0 && (Residuo = Numero % 2 === 0)){
    alert("su numero es par")
}else if (Division = Numero / 2 ===0 && (Residuo = Numero % 2 !== 0)){
    alert("Su primer digito es par y el segundo es impar")
}else if (Division = Numero / 2 !==0 && (Residuo = Numero % 2 ===0)){
    alert("Su primer digito es impar y el segundo digito es par")
}else
    alert("Su numero no es par")