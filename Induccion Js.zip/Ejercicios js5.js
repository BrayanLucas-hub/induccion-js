let Numero;

Numero=parseInt(prompt("Ingrese su numero"))

let decenas = Math.floor(Numero/10);
let unidades = Numero % 10;

if(unidades === 1){
    alert("su primer digito es " + decenas)
}else if(unidades === 2){
    alert("la suma de sus digitos es " + (decenas + unidades))
}else if(unidades === 3){
    alert("el producto de sus digitos es " + (decenas * unidades))
}
