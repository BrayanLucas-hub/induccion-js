let num1, num2;

num1 = parseInt(prompt("Ingrese el primer número"));
num2 = parseInt(prompt("Ingrese el segundo número"));

let diferencia = Math.abs(num1 - num2);

if (diferencia !== 0 && (num1 % diferencia === 0 || num2 % diferencia === 0)) {
    alert("La diferencia (" + diferencia + ") SÍ es divisor exacto de alguno de los dos números");
} else {
    alert("La diferencia (" + diferencia + ") NO es divisor exacto de ninguno de los dos números");
}