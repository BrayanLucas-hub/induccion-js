let Num;

Num=parseInt(prompt("Ingrese su numero"))

if(Num <0){
    alert("su numero es negativo")
}else{
    alert("Su numero es positivo")
}

